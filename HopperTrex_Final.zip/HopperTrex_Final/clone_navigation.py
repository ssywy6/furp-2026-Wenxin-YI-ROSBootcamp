"""Reproduce the CPU navigation actor from saved planner/DAgger examples."""
from pathlib import Path
import argparse
import numpy as np
import torch
from stable_baselines3 import PPO
from cpu_navigation import NavigationEnv
from cpu_balance import ROOT

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--data',type=Path,default=ROOT/'training_data/navigation_demonstrations.npz')
    p.add_argument('--model',type=Path,default=ROOT/'policy/cpu_avoid_cloned.zip')
    p.add_argument('--iterations',type=int,default=8000)
    a=p.parse_args()
    torch.set_num_threads(2);torch.manual_seed(17)
    with np.load(a.data) as data:
        x=torch.tensor(data['obs'],dtype=torch.float32)
        y=torch.tensor(data['actions'],dtype=torch.float32)
    env=NavigationEnv()
    if x.ndim!=2 or x.shape[1]!=47 or y.shape!=(len(x),2):
        raise ValueError('Expected 47 observation features and two navigation commands')
    model=PPO('MlpPolicy',env,device='cpu',seed=17,n_steps=512,batch_size=128,
        n_epochs=5,learning_rate=3e-4,gamma=.995,gae_lambda=.95,ent_coef=.001,
        target_kl=.02,policy_kwargs={'net_arch':[128,128]})
    opt=torch.optim.Adam(list(model.policy.mlp_extractor.policy_net.parameters())+
        list(model.policy.action_net.parameters()),lr=.001)
    for step in range(a.iterations):
        ix=torch.randint(len(x),(256,))
        pred=model.policy.get_distribution(x[ix]).distribution.mean
        loss=((pred-y[ix])**2).mean()
        opt.zero_grad();loss.backward();opt.step()
        if step%1000==0:print(step,loss.item(),flush=True)
    with torch.no_grad():model.policy.log_std.fill_(np.log(.12))
    model.hierarchical_navigation=True
    a.model.parent.mkdir(parents=True,exist_ok=True);model.save(a.model)
    env.close()

if __name__=='__main__':main()
