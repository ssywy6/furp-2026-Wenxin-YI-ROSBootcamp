param(
    [ValidateSet('stand','drive','avoid','stairs')][string]$Stage = 'stand',
    [ValidateSet('train','check','eval','view')][string]$Mode = 'view',
    [int]$Steps = 500000,
    [switch]$Resume,
    [string]$WarmStart,
    [string]$Model,
    [string]$Controller,
    [switch]$NoPlannerGuard,
    [int]$EvalSeed = 4000,
    [string]$EvaluationReport,
    [switch]$AcceptanceCheck,
    [double]$LearningRate = 0,
    [double[]]$StanceDeg,
    [double]$StairHeight = 0.02,
    [switch]$Descending
)
$ErrorActionPreference = 'Stop'
$localPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
$sessionPython = Join-Path $PSScriptRoot '..\..\work\venv\Scripts\python.exe'
if (Test-Path -LiteralPath $localPython) { $cpuPython = $localPython }
elseif (Test-Path -LiteralPath $sessionPython) { $cpuPython = $sessionPython }
else { throw 'Python environment not found. Follow CPU使用说明.md.' }
$cpuArgs = @((Join-Path $PSScriptRoot 'train_curriculum.py'), '--stage', $Stage, '--mode', $Mode, '--steps', "$Steps", '--stair-height', "$StairHeight")
if ($Resume) { $cpuArgs += '--resume' }
if ($WarmStart) { $cpuArgs += @('--warm-start', $WarmStart) }
if ($Model) { $cpuArgs += @('--model', $Model) }
if ($Controller) { $cpuArgs += @('--controller', $Controller) }
if ($NoPlannerGuard) { $cpuArgs += '--no-planner-guard' }
if ($Mode -eq 'eval') { $cpuArgs += @('--eval-seed', "$EvalSeed") }
if ($EvaluationReport) { $cpuArgs += @('--evaluation-report', $EvaluationReport) }
if ($AcceptanceCheck) { $cpuArgs += '--acceptance-check' }
if ($LearningRate -gt 0) { $cpuArgs += @('--learning-rate', "$LearningRate") }
if ($StanceDeg) {
    if ($StanceDeg.Count -ne 4) { throw 'StanceDeg requires four joint angles in degrees.' }
    $cpuArgs += '--stance-deg'
    $cpuArgs += @($StanceDeg | ForEach-Object { $_.ToString([Globalization.CultureInfo]::InvariantCulture) })
}
if ($Descending) { $cpuArgs += '--descending' }
& $cpuPython @cpuArgs
exit $LASTEXITCODE
