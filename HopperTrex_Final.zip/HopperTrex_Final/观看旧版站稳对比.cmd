@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-Curriculum.ps1" -Stage stand -Mode view -Model "%~dp0policy\cpu_stand_previous.zip"
if errorlevel 1 pause
