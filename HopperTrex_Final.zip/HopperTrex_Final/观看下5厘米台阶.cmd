@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-Curriculum.ps1" -Stage stairs -Mode view -StairHeight 0.05 -Descending
if errorlevel 1 pause
