"""Average compatible checkpoints from the same training chain, then evaluate."""
import argparse
from pathlib import Path
import torch
from stable_baselines3 import PPO

def main():
    p=argparse.ArgumentParser()
    p.add_argument('first',type=Path);p.add_argument('second',type=Path)
    p.add_argument('--alpha',type=float,default=.5)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    if not 0<=a.alpha<=1:p.error('alpha must be between zero and one')
    target=a.output if a.output.suffix=='.zip' else a.output.with_suffix('.zip')
    if target.exists():raise FileExistsError(target)
    first=PPO.load(a.first,device='cpu');second=PPO.load(a.second,device='cpu')
    if first.observation_space.shape!=second.observation_space.shape or first.action_space.shape!=second.action_space.shape:
        raise ValueError('Different observation/action dimensions')
    left=first.policy.state_dict();right=second.policy.state_dict()
    if left.keys()!=right.keys() or any(left[k].shape!=right[k].shape for k in left):
        raise ValueError('Different network architectures')
    with torch.no_grad():first.policy.load_state_dict({k:(1-a.alpha)*v+a.alpha*right[k] for k,v in left.items()})
    target.parent.mkdir(parents=True,exist_ok=True);first.save(target)
    print(f'Saved {target}; run deterministic evaluation before selecting it.')

if __name__=='__main__':main()
