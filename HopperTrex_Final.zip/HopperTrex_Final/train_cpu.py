"""Train, evaluate, or view the CPU-only balance policy."""
import argparse
import json
import time
from pathlib import Path
import numpy as np
import torch
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.callbacks import CheckpointCallback
from stable_baselines3.common.env_checker import check_env
from cpu_balance import BalanceEnv, ROOT

def evaluate(model, episodes=20, seconds=10., perturb_deg=np.rad2deg(0.025)):
    env = BalanceEnv()
    lengths, errors, drift = [], [], []
    for seed in range(1000, 1000 + episodes):
        obs, _ = env.reset(seed=seed, options={'perturb_rad':np.deg2rad(perturb_deg)})
        for step in range(round(seconds/0.02)):
            action = np.zeros(2) if model is None else model.predict(obs, deterministic=True)[0]
            obs, _, done, truncated, info = env.step(action)
            errors.append(abs(info['pitch_error']))
            if done or truncated:
                break
        lengths.append((step + 1)*0.02)
        drift.append(abs(info['drift_m']))
    return {'episodes': episodes, 'duration_s':seconds, 'initial_perturb_deg':float(perturb_deg), 'mean_survival_s': float(np.mean(lengths)),
        'full_duration_episodes': sum(x >= seconds for x in lengths),
        'mean_abs_pitch_error_deg': float(np.rad2deg(np.mean(errors))),
        'mean_final_abs_drift_m': float(np.mean(drift)),
        'target_pitch_deg': float(np.rad2deg(env.target_pitch))}

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--steps', type=int, default=500000)
    p.add_argument('--envs', type=int, default=4)
    p.add_argument('--seed', type=int, default=7)
    p.add_argument('--mode', choices=['train', 'check', 'eval', 'view'], default='train')
    p.add_argument('--model', type=Path, default=ROOT/'policy/cpu_balance.zip')
    p.add_argument('--resume', action='store_true')
    p.add_argument('--seconds', type=float, default=60.)
    p.add_argument('--perturb-deg', type=float, default=float(np.rad2deg(0.025)))
    args = p.parse_args()
    if not 0.02 <= args.seconds <= 60. or not 0. <= args.perturb_deg <= 10.:
        p.error('--seconds must be in [0.02, 60], --perturb-deg in [0, 10]')
    torch.set_num_threads(2)
    if args.mode == 'check':
        check_env(BalanceEnv())
        print(json.dumps({'zero_action': evaluate(None)}, indent=2))
        return
    if args.mode == 'train':
        env = make_vec_env(BalanceEnv, n_envs=args.envs, seed=args.seed)
        model = PPO.load(args.model, env=env, device='cpu') if args.resume else PPO(
            'MlpPolicy', env, device='cpu', seed=args.seed, n_steps=512,
            batch_size=128, n_epochs=5, learning_rate=3e-4, gamma=0.99,
            gae_lambda=0.95, ent_coef=0.001, policy_kwargs={'net_arch':[64,64]}, verbose=1)
        args.model.parent.mkdir(parents=True, exist_ok=True)
        model.learn(args.steps, reset_num_timesteps=not args.resume, callback=CheckpointCallback(
            save_freq=max(1, 50000//args.envs), save_path=str(args.model.parent/'checkpoints')))
        model.save(args.model)
        report = {'zero_action':evaluate(None), 'trained':evaluate(model)}
        (args.model.parent/'evaluation.json').write_text(json.dumps(report, indent=2))
        print(json.dumps(report, indent=2))
    elif args.mode == 'eval':
        report = {'zero_action':evaluate(None, seconds=args.seconds, perturb_deg=args.perturb_deg),
            'trained':evaluate(PPO.load(args.model, device='cpu'), seconds=args.seconds, perturb_deg=args.perturb_deg)}
        (args.model.parent/f'evaluation_{args.seconds:g}s_{args.perturb_deg:g}deg.json').write_text(json.dumps(report, indent=2))
        print(json.dumps(report, indent=2))
    else:
        import mujoco.viewer
        model = PPO.load(args.model, device='cpu')
        env = BalanceEnv()
        obs, _ = env.reset(seed=1000)
        with mujoco.viewer.launch_passive(env.model, env.data) as viewer:
            while viewer.is_running():
                start = time.perf_counter()
                obs, _, done, truncated, _ = env.step(model.predict(obs, deterministic=True)[0])
                if done or truncated:
                    obs, _ = env.reset()
                viewer.sync()
                time.sleep(max(0., .02-(time.perf_counter()-start)))

if __name__ == '__main__':
    main()
