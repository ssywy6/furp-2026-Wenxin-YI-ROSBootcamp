@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-Curriculum.ps1" -Stage stairs -Mode view -StairHeight 0.03
if errorlevel 1 pause
