param(
    [ValidateSet('train','check','eval','view')][string]$Mode = 'view',
    [int]$Steps = 500000,
    [switch]$Resume
)
$ErrorActionPreference = 'Stop'
$localPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
$sessionPython = Join-Path $PSScriptRoot '..\..\work\venv\Scripts\python.exe'
if (Test-Path -LiteralPath $localPython) { $cpuPython = $localPython }
elseif (Test-Path -LiteralPath $sessionPython) { $cpuPython = $sessionPython }
else { throw 'Python environment not found. Follow CPU使用说明.md to install dependencies.' }
$cpuArgs = @((Join-Path $PSScriptRoot 'train_cpu.py'), '--mode', $Mode, '--steps', "$Steps")
if ($Resume) { $cpuArgs += '--resume' }
& $cpuPython @cpuArgs
exit $LASTEXITCODE
