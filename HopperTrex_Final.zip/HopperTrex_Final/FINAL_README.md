# HopperTrex CPU RL — Final Submission

## 中文使用说明

本项目使用 MuJoCo 和 PPO，在 CPU 上训练 HopperTrex 两轮机器人通过三段 2 cm 矮台阶，并加入随机突发外力训练。

最终模型：`policy/cpu_stairs_up_2cm_push.zip`，这是 Stable-Baselines3 模型文件，不要解压。

### Windows 安装和展示

安装 Python 3.11，在本文件夹打开 PowerShell，执行：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-cpu.txt
.\.venv\Scripts\python.exe train_curriculum.py --stage stairs --mode view --stair-height .02 --model policy/cpu_stairs_up_2cm_push.zip
```

### 重新验证

```powershell
.\.venv\Scripts\python.exe train_curriculum.py --stage stairs --mode eval --stair-height .02 --model policy/cpu_stairs_up_2cm_push.zip
.\.venv\Scripts\python.exe evaluate_push.py
```

### 继续抗推力训练

```powershell
.\.venv\Scripts\python.exe train_curriculum.py --stage stairs --steps 100000 --warm-start policy/cpu_stairs_up_2cm_push.zip --model policy/cpu_stairs_up_2cm_push_v2.zip --learning-rate .00005 --push-training
```

## Results and scope

The final policy was fine-tuned for 100,352 simulation steps from an existing 2 cm stair policy. Random horizontal forces of 8–18 N were applied for one 0.02 s control interval. The first push is scheduled approximately 1–3.6 seconds into an episode, with subsequent intervals of 2–6 seconds. Short episodes may finish before a scheduled push occurs.

- Standard deterministic stair evaluation: 18/20 successful episodes.
- Evaluation with random push scheduling enabled: 9/10 successful episodes, seeds 5000–5009.
- Reports: `policy/cpu_stairs_up_2cm_push_evaluation.json` and `policy/cpu_stairs_up_2cm_push_robust_evaluation.json`.

These are small simulation evaluations. The push report is a summary, and no matched baseline push evaluation was performed, so it does not establish an improvement in robustness over the original model. Use `evaluate_push.py` to generate per-episode results.

This submission covers simulated low-stair locomotion and external-force training. It does not implement a manipulator, a QP whole-body controller, or real-robot deployment. Do not describe these as completed merely because the repository title mentions them.

## Files

- `assets/hoppertrex/`: required MuJoCo robot XML and mesh files.
- `policy/cpu_stairs_up_2cm_push.zip`: final model.
- `cpu_*.py`: simulation source and supporting controllers.
- `train_curriculum.py`: training, evaluation and visualization.
- Other policies and original documentation are retained as prior project work; this file identifies the final submission.
