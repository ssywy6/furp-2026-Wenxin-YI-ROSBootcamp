# HopperTrex CPU 版本

推荐入口：Start-Curriculum.ps1。实际能力与评估结果见 [分阶段训练说明.md](分阶段训练说明.md)。原桌面项目未修改；此目录保留原文件用于对照，CPU 训练入口使用原生 MuJoCo、Gymnasium、PyTorch 与 Stable Baselines3，不依赖 CUDA/MjLab。

不熟悉仿真窗口时，先读 [MuJoCo第一次使用.md](MuJoCo第一次使用.md)。2026-10-09 已更新更安静的站稳权重和更清楚的地形显示。

## 本机直接运行

在本目录打开 PowerShell：

```powershell
powershell -ExecutionPolicy Bypass -File .\Start-Curriculum.ps1 -Stage stand -Mode view
powershell -ExecutionPolicy Bypass -File .\Start-Curriculum.ps1 -Stage drive -Mode view
powershell -ExecutionPolicy Bypass -File .\Start-Curriculum.ps1 -Stage avoid -Mode view
powershell -ExecutionPolicy Bypass -File .\Start-Curriculum.ps1 -Stage stairs -Mode view -StairHeight 0.03
powershell -ExecutionPolicy Bypass -File .\Start-Curriculum.ps1 -Stage stairs -Mode view -Descending -StairHeight 0.05
```

本机启动器自动使用本次安装的 CPU 环境。关闭仿真窗口退出；把 view 改为 eval 可评估。上/下行方向和台阶高度必须与选定权重匹配。5厘米下行仍有失败，4厘米上行属于实验模型。

## 复制到其他位置或电脑

使用 Python 3.12，在本目录建立环境：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-cpu.txt
powershell -ExecutionPolicy Bypass -File .\Start-Curriculum.ps1 -Stage stand -Mode view
```

启动器优先使用本目录 .venv。压缩包不包含 Python 环境或庞大的训练检查点。依赖固定为本次实际测试版本。

## 继续训练

参照分阶段训练说明，用新实验文件保存训练结果。先站稳，再行驶、绕障、低台阶；需要保存最佳策略并用独立种子复测。早期 train_cpu.py / Start-CPU.ps1 只是历史平衡实验，允许明显漂移，不作为当前推荐入口。

这是理想感知下的仿真训练，尚未验证普通建筑楼梯或真实机器人。避障默认使用已知地图规划保护，具体接管比例与纯学习成功率见评估报告。
