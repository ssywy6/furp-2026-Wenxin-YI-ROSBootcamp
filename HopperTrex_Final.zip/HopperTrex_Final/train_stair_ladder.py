"""Advance CPU stair training only after deterministic evaluation passes."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
from cpu_balance import ROOT

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--warm-start',type=Path,required=True)
    p.add_argument('--heights',type=float,nargs='+',default=[.015,.02,.025,.03,.04,.05])
    p.add_argument('--steps',type=int,default=200000)
    p.add_argument('--learning-rate',type=float,default=.0001)
    p.add_argument('--descending',action='store_true')
    a=p.parse_args()
    if a.steps<1 or any(not .005<=h<=.1 for h in a.heights):
        p.error('Positive steps and heights between .005 and .1 metres required')
    source=a.warm_start.resolve()
    results=[]
    for h in a.heights:
        label=f'{h*100:g}'.replace('.','p')
        direction='down' if a.descending else 'up'
        target=ROOT/f'policy/cpu_stairs_{direction}_{label}cm.zip'
        if target.exists():
            raise FileExistsError(f'{target}: preserve or rename existing weights before rerunning')
        command=[sys.executable,str(ROOT/'train_curriculum.py'),'--stage','stairs',
            '--mode','train','--stair-height',str(h),'--steps',str(a.steps),
            '--warm-start',str(source),'--model',str(target),'--learning-rate',str(a.learning_rate),'--acceptance-check']
        if a.descending:command.append('--descending')
        subprocess.run(command,check=True)
        report=json.loads(target.with_name(target.stem+'_evaluation.json').read_text())
        results.append({'height_m':h,'model':target.name,'passed':report['passed'],
            'episodes':report['episodes']})
        (ROOT/f'policy/stair_ladder_{direction}_progress.json').write_text(json.dumps(results,indent=2))
        if report['passed']!=report['episodes']:
            print('Stopped: deterministic evaluation did not pass every episode.',flush=True)
            return
        source=target

if __name__=='__main__':main()
