@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-Curriculum.ps1" -Stage stand -Mode view
if errorlevel 1 pause
