"""Evaluate final stair policy with scheduled random external forces."""
import json
from pathlib import Path
import torch
from stable_baselines3 import PPO
from cpu_terrain import TerrainEnv

def main():
    torch.set_num_threads(2)
    root = Path(__file__).resolve().parent
    model = PPO.load(root / 'policy/cpu_stairs_up_2cm_push.zip', device='cpu')
    env = TerrainEnv('stairs', .02, push_training=True)
    rows = []
    for seed in range(5000, 5010):
        obs, _ = env.reset(seed=seed)
        for step in range(3000):
            obs, _, done, timeout, info = env.step(model.predict(obs, deterministic=True)[0])
            if done or timeout:
                break
        rows.append(dict(seed=seed, success=bool(info['success']), seconds=(step+1)*.02))
    env.close()
    print(json.dumps(dict(episodes=len(rows), passed=sum(r['success'] for r in rows), results=rows), indent=2))

if __name__ == '__main__':
    main()
